In the folder named "current", there are images named im1, im2
and there are corresponding predictions im1a, im2a, etc. By changing
the path appropriately in the cv2.imread(), you can run whatever
metric you need to.

